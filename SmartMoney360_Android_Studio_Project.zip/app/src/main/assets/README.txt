SMART MONEY 360 — INSTALLABLE PWA

1. Upload these files to a web host that gives you an HTTPS link (for example GitHub Pages).
2. Open the HTTPS link on your Android phone in Chrome.
3. Tap ⋮ > Add to Home screen (or Install app).
4. The app will appear on your home screen as "Smart Money" with the supplied logo icon.

For the college project, the easiest route is GitHub Pages:
- Create a GitHub repository.
- Upload index.html, manifest.json, sw.js and icon-512.png.
- Enable Pages for the repository.
- Open the generated HTTPS page on your phone.
