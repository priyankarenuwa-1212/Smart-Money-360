# Smart Money 360 — Android APK Project

This project wraps the exact Smart Money 360 HTML prototype in a native Android WebView.

## App identity
- Name: Smart Money 360
- Application ID: com.smartmoney360.app
- Orientation: Portrait
- Launcher icon: Smart Money logo supplied with the prototype

## Open in Android Studio
1. Install Android Studio.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press Run ▶.
6. To create an APK: Build → Build APK(s).

The generated debug APK is normally under:
app/build/outputs/apk/debug/app-debug.apk

## Important
The app is a prototype. Financial calculations and educational responses are for demonstration and are not connected to real bank accounts, investments, payments, or regulated financial services.
